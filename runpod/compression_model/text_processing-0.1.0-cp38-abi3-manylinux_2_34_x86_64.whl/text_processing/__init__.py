from .text_processing import *

__doc__ = text_processing.__doc__
if hasattr(text_processing, "__all__"):
    __all__ = text_processing.__all__